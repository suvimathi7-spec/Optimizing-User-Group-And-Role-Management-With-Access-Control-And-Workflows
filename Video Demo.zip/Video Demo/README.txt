### Optimizing-User-Group-and-Role-Management-with-Access-Control-and-Workflows



Here You will find all the document files related to the " Prevent user deletion if assigned to an incident" Project.



Team ID : NM2025TMID01765



Team Size : 5



Team Leader : Ashokkumar T



Team member : �Karthi K



Team member : Ranjitha K



Team member : �Suvitha M



Team member : �Priyanga R



Servicenow Instance: [https://developer.servicenow.com/dev.do#!/home?wu=true](https://developer.servicenow.com/dev.do#!/home?wu=true)



Demo Vedio Link: [https://drive.google.com/file/d/1DNRoxz3pRZTQRFFECd3t1o2WToXKEOiE/view?usp=sharing](https://drive.google.com/file/d/1DNRoxz3pRZTQRFFECd3t1o2WToXKEOiE/view?usp=sharing)

