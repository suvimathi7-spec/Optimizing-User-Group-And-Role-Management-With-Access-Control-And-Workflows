Here you will find the pdf file about the Project Planning Phase consist of Project Planning

