Here you will find the pdf files about the Project Design Phase consists of



1.Problem Solution Fit

2.Proposed Solution

3.Solution Architecture

